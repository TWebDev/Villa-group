Hello,

Thank for purchasing and using Broetown Signature.
If there is a problem, question, or anything about my fonts, please sent an email to
ocansproject33@gmail.com

How to install fonts :
Windows 7-10:
https://support.microsoft.com/help/314960/how-to-install-or-remove-a-font-in-windows
Mac OS:
https://support.apple.com/en-us/HT201749


Happy creating!
Thank You, 


Oki Candra Setiawan (OcansProject33)
